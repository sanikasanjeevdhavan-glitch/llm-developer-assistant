"""
=============================================================================
LLM-Powered Developer Assistant — Production MVP
=============================================================================
Tech Stack : Python · FastAPI · LangChain · OpenAI API
Author     : (your name here)
Purpose    : Agentic backend tool for code review, bug detection, optimization,
             test-case generation, and contextual chat — demo-ready for
             Horizon Labs SD intern interview.

SYSTEM DESIGN OVERVIEW
─────────────────────
 ┌──────────────┐     ┌─────────────────┐     ┌─────────────────┐
 │  FastAPI     │────▶│  Service Layer   │────▶│  LLM Wrapper    │
 │  (Routes)    │     │  (Business Logic)│     │  (LangChain /   │
 └──────────────┘     └─────────────────┘     │   OpenAI)       │
        │                      │               └─────────────────┘
        │              ┌───────┴───────┐
        │              │               │
        ▼              ▼               ▼
   Rate Limiter   Memory Store    Response Cache
  (per-IP dict)  (last 5 turns)  (SHA-256 keyed)

WHY THIS STRUCTURE?
  • Separating routes from service logic makes unit-testing trivial — you
    can swap the LLM backend without touching any route handler.
  • In production this would split across microservices; keeping it in one
    file for demo purposes does NOT mean the thinking is monolithic.
  • In-memory cache/memory trade simplicity vs Redis/PostgreSQL at scale
    (discussed in the TRADEOFFS section at the bottom of this file).
=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import asyncio
import hashlib
import json
import logging
import os
import time
from collections import defaultdict
from typing import Any, Dict, List, Optional

# ── Third-party ───────────────────────────────────────────────────────────
import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, field_validator

# Load .env file when running locally (no-op in production where env vars are
# injected by the platform, e.g. Railway / Render / Fly.io)
load_dotenv()

# LangChain — switched to community/openai split packages (>=0.2)
from langchain.schema import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI

# ── Logging setup ─────────────────────────────────────────────────────────
# Using the stdlib logger (not print) so log levels can be toggled in prod.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("dev_assistant")


# =============================================================================
# SECTION 1 — CONFIGURATION
# Centralised config keeps environment-specific values out of business logic.
# =============================================================================

class Config:
    """Central configuration — swap values via env vars in production."""

    OPENAI_MODEL: str = "gpt-4o-mini"          # cheaper/faster for demos
    OPENAI_TEMPERATURE: float = 0.2             # low temp → deterministic code output
    MAX_TOKENS: int = 2048
    MAX_RETRIES: int = 3
    RETRY_DELAY: float = 1.5                    # seconds between retries

    # Rate limiting — simple in-memory token-bucket per IP
    RATE_LIMIT_REQUESTS: int = 30               # requests allowed
    RATE_LIMIT_WINDOW: int = 60                 # per N seconds

    # Conversation memory — only keep last N turns to control context size.
    # TRADEOFF: Larger window = better context but higher token cost.
    MEMORY_WINDOW: int = 5

    # Cache TTL in seconds.
    # TRADEOFF: In-memory cache is lost on restart; Redis would be persistent.
    CACHE_TTL: int = 300


# =============================================================================
# SECTION 2 — PYDANTIC SCHEMAS (Request / Response Models)
# =============================================================================

class CodeAnalysisRequest(BaseModel):
    code: str
    language: Optional[str] = "python"

    @field_validator("code")
    @classmethod
    def code_must_not_be_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("code must not be empty")
        return v.strip()


class MultiFileAnalysisRequest(BaseModel):
    """Bonus: analyse multiple code files in one request."""
    files: List[CodeAnalysisRequest]


class OptimizeRequest(BaseModel):
    code: str
    language: Optional[str] = "python"

    @field_validator("code")
    @classmethod
    def code_must_not_be_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("code must not be empty")
        return v.strip()


class ChatRequest(BaseModel):
    query: str
    code_context: Optional[str] = None
    session_id: Optional[str] = "default"      # allows multi-user sessions

    @field_validator("query")
    @classmethod
    def query_must_not_be_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("query must not be empty")
        return v.strip()


class AnalysisResponse(BaseModel):
    explanation: str
    bugs: List[str]
    suggested_fixes: List[str]
    latency_ms: float


class OptimizeResponse(BaseModel):
    optimized_code: str
    improvements: List[str]
    latency_ms: float


class ChatResponse(BaseModel):
    response: str
    session_id: str
    latency_ms: float


# =============================================================================
# SECTION 3 — IN-MEMORY CACHE
# SHA-256 of the prompt is the key so identical requests hit the cache.
# SCALE NOTE: Replace with Redis (redis-py / aioredis) for distributed caching.
# =============================================================================

class ResponseCache:
    """Simple TTL-aware in-memory cache."""

    def __init__(self, ttl: int = Config.CACHE_TTL):
        self._store: Dict[str, Dict[str, Any]] = {}
        self._ttl = ttl

    def _make_key(self, text: str) -> str:
        return hashlib.sha256(text.encode()).hexdigest()

    def get(self, prompt: str) -> Optional[Any]:
        key = self._make_key(prompt)
        entry = self._store.get(key)
        if entry and (time.time() - entry["ts"] < self._ttl):
            logger.info("Cache HIT for key %s…", key[:12])
            return entry["value"]
        return None

    def set(self, prompt: str, value: Any) -> None:
        key = self._make_key(prompt)
        self._store[key] = {"value": value, "ts": time.time()}
        logger.info("Cache SET for key %s…", key[:12])

    def invalidate(self, prompt: str) -> None:
        self._store.pop(self._make_key(prompt), None)


# =============================================================================
# SECTION 4 — CONVERSATION MEMORY
# Stores the last N (human, assistant) turn pairs per session_id.
# SCALE NOTE: Replace with LangChain's RedisChatMessageHistory for persistence.
# =============================================================================

class ConversationMemory:
    """Per-session sliding-window message history."""

    def __init__(self, window: int = Config.MEMORY_WINDOW):
        # defaultdict means we never need to initialise a session manually.
        self._sessions: Dict[str, List[Dict[str, str]]] = defaultdict(list)
        self._window = window

    def add(self, session_id: str, role: str, content: str) -> None:
        self._sessions[session_id].append({"role": role, "content": content})
        # Trim to sliding window (keep last window * 2 messages = N full turns)
        self._sessions[session_id] = self._sessions[session_id][-(self._window * 2):]

    def get_history(self, session_id: str) -> List[Dict[str, str]]:
        return self._sessions.get(session_id, [])

    def clear(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)


# =============================================================================
# SECTION 5 — LLM WRAPPER
# Abstracts the LangChain / OpenAI surface behind a clean interface.
# WHY: If we swap to Anthropic/Gemini, only THIS class changes — routes don't.
# =============================================================================

class LLMWrapper:
    """
    Central LangChain/OpenAI wrapper with:
      • Structured prompt construction (system + user + context)
      • Async invocation
      • Exponential-backoff retry
      • Fallback responses on hard failure
    """

    def __init__(self):
        # DESIGN DECISION: temperature=0.2 keeps code suggestions reproducible.
        # For creative/chat tasks you'd bump this to 0.7+.
        self._llm = ChatOpenAI(
            model=Config.OPENAI_MODEL,
            temperature=Config.OPENAI_TEMPERATURE,
            max_tokens=Config.MAX_TOKENS,
        )
        logger.info("LLMWrapper initialised with model=%s", Config.OPENAI_MODEL)

    async def invoke(
        self,
        system_prompt: str,
        user_prompt: str,
        context: Optional[str] = None,
        history: Optional[List[Dict[str, str]]] = None,
    ) -> str:
        """
        Build a structured message list and call the LLM asynchronously.

        Args:
            system_prompt : Sets the assistant persona/rules.
            user_prompt   : The actual task/question.
            context       : Optional extra context injected before the question.
            history       : Prior conversation turns for memory-aware responses.

        Returns:
            The LLM's text response.
        """
        messages = [SystemMessage(content=system_prompt)]

        # Replay conversation history so the model has context
        if history:
            for turn in history:
                if turn["role"] == "user":
                    messages.append(HumanMessage(content=turn["content"]))
                else:
                    # LangChain AIMessage — we import lazily to keep imports clean
                    from langchain.schema import AIMessage  # noqa: PLC0415
                    messages.append(AIMessage(content=turn["content"]))

        # Context injection (e.g., a code snippet) goes BEFORE the user question
        if context:
            messages.append(HumanMessage(content=f"[CONTEXT]\n{context}\n[/CONTEXT]"))

        messages.append(HumanMessage(content=user_prompt))

        return await self._invoke_with_retry(messages)

    async def _invoke_with_retry(self, messages: list) -> str:
        """Retry with exponential backoff on transient failures."""
        last_exc: Optional[Exception] = None
        for attempt in range(1, Config.MAX_RETRIES + 1):
            try:
                logger.info("LLM call attempt %d/%d", attempt, Config.MAX_RETRIES)
                response = await self._llm.ainvoke(messages)
                return response.content
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                wait = Config.RETRY_DELAY * (2 ** (attempt - 1))
                logger.warning("LLM attempt %d failed: %s — retrying in %.1fs", attempt, exc, wait)
                await asyncio.sleep(wait)

        # All retries exhausted — return a graceful fallback
        logger.error("All LLM retries failed. Last error: %s", last_exc)
        return (
            "⚠️ The AI service is temporarily unavailable. "
            "Please try again in a moment."
        )


# =============================================================================
# SECTION 6 — SERVICE LAYER
# Pure business logic — no HTTP concepts here (no Request/Response objects).
# This is the layer you'd unit-test in isolation.
# =============================================================================

class CodeAnalysisService:
    """Handles /analyze-code and /analyze-multi logic."""

    _SYSTEM_PROMPT = (
        "You are a senior software engineer conducting a thorough code review. "
        "Be precise, actionable, and brief. Always respond in valid JSON."
    )

    def __init__(self, llm: LLMWrapper, cache: ResponseCache):
        self._llm = llm
        self._cache = cache

    async def analyze(self, code: str, language: str = "python") -> Dict[str, Any]:
        """
        Analyse a single code snippet.

        Returns a dict with keys: explanation, bugs, suggested_fixes.
        """
        prompt = f"""
Analyse the following {language} code and respond ONLY with a JSON object
(no markdown fences) matching this exact schema:
{{
  "explanation": "<1-3 sentence plain-English explanation>",
  "bugs": ["<bug 1>", "<bug 2>"],
  "suggested_fixes": ["<fix 1>", "<fix 2>"]
}}

CODE:
{code}
""".strip()

        # Cache check — avoid paying for the same LLM call twice
        cached = self._cache.get(prompt)
        if cached:
            return cached

        raw = await self._llm.invoke(self._SYSTEM_PROMPT, prompt)
        result = self._parse_json(raw, fallback_explanation=raw)
        self._cache.set(prompt, result)
        return result

    async def analyze_multi(self, files: List[Dict[str, str]]) -> List[Dict[str, Any]]:
        """Analyse multiple files concurrently using asyncio.gather."""
        # DESIGN DECISION: gather() parallelises I/O-bound LLM calls, which is
        # far faster than a sequential loop when processing many files.
        tasks = [self.analyze(f["code"], f.get("language", "python")) for f in files]
        return list(await asyncio.gather(*tasks))

    @staticmethod
    def _parse_json(raw: str, fallback_explanation: str = "") -> Dict[str, Any]:
        """Safely parse JSON from LLM output, with graceful fallback."""
        try:
            # Strip accidental markdown fences the model sometimes adds
            clean = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
            return json.loads(clean)
        except json.JSONDecodeError:
            logger.warning("LLM returned non-JSON: %s…", raw[:80])
            return {
                "explanation": fallback_explanation,
                "bugs": [],
                "suggested_fixes": ["Could not parse structured response; see explanation."],
            }


class OptimizationService:
    """Handles /optimize-code logic."""

    _SYSTEM_PROMPT = (
        "You are a performance-focused software engineer. "
        "Optimise the given code for readability, performance, and best practices. "
        "Always respond in valid JSON."
    )

    def __init__(self, llm: LLMWrapper, cache: ResponseCache):
        self._llm = llm
        self._cache = cache

    async def optimize(self, code: str, language: str = "python") -> Dict[str, Any]:
        prompt = f"""
Optimise the following {language} code and respond ONLY with a JSON object
(no markdown fences) matching this exact schema:
{{
  "optimized_code": "<full optimised code here>",
  "improvements": ["<improvement 1>", "<improvement 2>"]
}}

ORIGINAL CODE:
{code}
""".strip()

        cached = self._cache.get(prompt)
        if cached:
            return cached

        raw = await self._llm.invoke(self._SYSTEM_PROMPT, prompt)
        result = self._parse_json(raw, original_code=code)
        self._cache.set(prompt, result)
        return result

    @staticmethod
    def _parse_json(raw: str, original_code: str = "") -> Dict[str, Any]:
        try:
            clean = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
            return json.loads(clean)
        except json.JSONDecodeError:
            return {"optimized_code": original_code, "improvements": [raw]}


class ChatService:
    """Handles /chat with sliding-window conversation memory."""

    _SYSTEM_PROMPT = (
        "You are an expert developer assistant. Answer concisely and accurately. "
        "When shown code, analyse it in your response. "
        "Keep answers focused and developer-friendly."
    )

    def __init__(self, llm: LLMWrapper, memory: ConversationMemory):
        self._llm = llm
        self._memory = memory

    async def chat(
        self,
        query: str,
        session_id: str,
        code_context: Optional[str] = None,
    ) -> str:
        history = self._memory.get_history(session_id)

        response = await self._llm.invoke(
            system_prompt=self._SYSTEM_PROMPT,
            user_prompt=query,
            context=code_context,
            history=history,
        )

        # Persist this turn into memory AFTER the call
        self._memory.add(session_id, "user", query)
        self._memory.add(session_id, "assistant", response)
        return response


# =============================================================================
# SECTION 7 — RATE LIMITER
# Simple sliding-window counter per IP.
# SCALE NOTE: Use a Redis INCR + EXPIRE in production for distributed limiting.
# =============================================================================

class RateLimiter:
    """Per-IP request counter with a rolling time window."""

    def __init__(
        self,
        max_requests: int = Config.RATE_LIMIT_REQUESTS,
        window_seconds: int = Config.RATE_LIMIT_WINDOW,
    ):
        self._max = max_requests
        self._window = window_seconds
        # { ip: [(timestamp, count), ...] }
        self._buckets: Dict[str, List[float]] = defaultdict(list)

    def is_allowed(self, ip: str) -> bool:
        now = time.time()
        # Drop timestamps outside the current window
        self._buckets[ip] = [t for t in self._buckets[ip] if now - t < self._window]

        if len(self._buckets[ip]) >= self._max:
            logger.warning("Rate limit exceeded for IP %s", ip)
            return False

        self._buckets[ip].append(now)
        return True


# =============================================================================
# SECTION 8 — FASTAPI APPLICATION + DEPENDENCY WIRING
# Initialise shared singletons once at startup (not per-request).
# =============================================================================

app = FastAPI(
    title="LLM Developer Assistant",
    description="Agentic code review, bug detection, and optimisation API.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=([o.strip() for o in os.getenv("ALLOWED_ORIGINS","*").split(",")] if os.getenv("ALLOWED_ORIGINS","*") != "*" else ["*"]),
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Singleton instances ────────────────────────────────────────────────────
_cache = ResponseCache()
_memory = ConversationMemory()
_llm = LLMWrapper()
_rate_limiter = RateLimiter()

_analysis_svc = CodeAnalysisService(_llm, _cache)
_optimize_svc = OptimizationService(_llm, _cache)
_chat_svc = ChatService(_llm, _memory)


# =============================================================================
# SECTION 9 — MIDDLEWARE (telemetry + rate limiting)
# Using a single middleware keeps route handlers clean.
# =============================================================================

@app.middleware("http")
async def telemetry_and_rate_limit(request: Request, call_next):
    """Log latency for every request; enforce per-IP rate limiting."""
    ip = request.client.host if request.client else "unknown"

    if not _rate_limiter.is_allowed(ip):
        return JSONResponse(
            status_code=429,
            content={"detail": "Rate limit exceeded. Please slow down."},
        )

    start = time.perf_counter()
    response = await call_next(request)
    latency = (time.perf_counter() - start) * 1000

    logger.info(
        "%-6s %-40s  %d  %.1fms",
        request.method,
        request.url.path,
        response.status_code,
        latency,
    )
    response.headers["X-Response-Time-Ms"] = f"{latency:.1f}"
    return response


# =============================================================================
# SECTION 10 — ROUTE HANDLERS
# Thin layer: validate → delegate to service → wrap in response model.
# =============================================================================

@app.post("/analyze-code", response_model=AnalysisResponse, tags=["Analysis"])
async def analyze_code(req: CodeAnalysisRequest):
    """
    Analyse a code snippet for explanation, bugs, and suggested fixes.

    - **code**: The source code string to analyse.
    - **language**: Programming language hint (default: python).
    """
    start = time.perf_counter()
    try:
        result = await _analysis_svc.analyze(req.code, req.language or "python")
    except Exception as exc:
        logger.exception("analyze_code failed")
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    latency_ms = (time.perf_counter() - start) * 1000
    return AnalysisResponse(
        explanation=result.get("explanation", ""),
        bugs=result.get("bugs", []),
        suggested_fixes=result.get("suggested_fixes", []),
        latency_ms=round(latency_ms, 2),
    )


@app.post("/analyze-multi", tags=["Analysis"])
async def analyze_multi(req: MultiFileAnalysisRequest):
    """
    Bonus endpoint: analyse multiple files concurrently.

    Useful for whole-repo review workflows (e.g., triggered by GitHub Actions).
    """
    start = time.perf_counter()
    files = [{"code": f.code, "language": f.language} for f in req.files]
    try:
        results = await _analysis_svc.analyze_multi(files)
    except Exception as exc:
        logger.exception("analyze_multi failed")
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    latency_ms = (time.perf_counter() - start) * 1000
    return {"results": results, "latency_ms": round(latency_ms, 2)}


@app.post("/optimize-code", response_model=OptimizeResponse, tags=["Optimization"])
async def optimize_code(req: OptimizeRequest):
    """
    Return an optimised version of the submitted code with an explanation
    of every improvement made.
    """
    start = time.perf_counter()
    try:
        result = await _optimize_svc.optimize(req.code, req.language or "python")
    except Exception as exc:
        logger.exception("optimize_code failed")
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    latency_ms = (time.perf_counter() - start) * 1000
    return OptimizeResponse(
        optimized_code=result.get("optimized_code", req.code),
        improvements=result.get("improvements", []),
        latency_ms=round(latency_ms, 2),
    )


@app.post("/chat", response_model=ChatResponse, tags=["Chat"])
async def chat(req: ChatRequest):
    """
    Conversational assistant with sliding-window memory.

    - **query**: Your question or instruction.
    - **code_context**: Optional code snippet for context.
    - **session_id**: Use a consistent ID per user to maintain conversation history.
    """
    start = time.perf_counter()
    try:
        response_text = await _chat_svc.chat(
            query=req.query,
            session_id=req.session_id or "default",
            code_context=req.code_context,
        )
    except Exception as exc:
        logger.exception("chat failed")
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    latency_ms = (time.perf_counter() - start) * 1000
    return ChatResponse(
        response=response_text,
        session_id=req.session_id or "default",
        latency_ms=round(latency_ms, 2),
    )


@app.get("/health", tags=["Ops"])
async def health():
    """Lightweight liveness probe for CI/CD and load balancers."""
    return {"status": "ok", "model": Config.OPENAI_MODEL}


@app.delete("/chat/memory/{session_id}", tags=["Chat"])
async def clear_memory(session_id: str):
    """Clear conversation history for a specific session."""
    _memory.clear(session_id)
    return {"cleared": session_id}


# =============================================================================
# SECTION 11 — ENTRY POINT
# =============================================================================

def main():
    """
    Start the FastAPI server with uvicorn.

    In production you'd use gunicorn + uvicorn workers:
        gunicorn main:app -k uvicorn.workers.UvicornWorker -w 4
    """
    logger.info("Starting LLM Developer Assistant…")
    uvicorn.run(
        "llm_developer_assistant:app",   # module:app string for hot-reload
        host="0.0.0.0",
        port=8000,
        reload=True,   # set False in production
        log_level="info",
    )


if __name__ == "__main__":
    main()


# =============================================================================
# EXAMPLE CURL REQUESTS
# =============================================================================
#
# 1. Analyse code
# ───────────────
# curl -X POST http://localhost:8000/analyze-code \
#   -H "Content-Type: application/json" \
#   -d '{
#         "code": "def add(a, b):\n    return a - b",
#         "language": "python"
#       }'
#
# 2. Optimise code
# ────────────────
# curl -X POST http://localhost:8000/optimize-code \
#   -H "Content-Type: application/json" \
#   -d '{
#         "code": "result = []\nfor i in range(100):\n    result.append(i*i)",
#         "language": "python"
#       }'
#
# 3. Chat with memory
# ───────────────────
# curl -X POST http://localhost:8000/chat \
#   -H "Content-Type: application/json" \
#   -d '{
#         "query": "What does this function do?",
#         "code_context": "def fib(n):\n    if n<=1: return n\n    return fib(n-1)+fib(n-2)",
#         "session_id": "user-001"
#       }'
#
# 4. Multi-file analysis
# ──────────────────────
# curl -X POST http://localhost:8000/analyze-multi \
#   -H "Content-Type: application/json" \
#   -d '{
#         "files": [
#           {"code": "x = 1/0", "language": "python"},
#           {"code": "SELECT * FROM users", "language": "sql"}
#         ]
#       }'
#
# 5. Health check
# ───────────────
# curl http://localhost:8000/health
#
# 6. Clear session memory
# ───────────────────────
# curl -X DELETE http://localhost:8000/chat/memory/user-001


# =============================================================================
# TRADEOFFS — know these for the interview
# =============================================================================
#
# Component          Current (MVP)          Production alternative
# ─────────────────────────────────────────────────────────────────
# Cache              In-memory dict         Redis (persistent, distributed)
# Memory             In-memory defaultdict  RedisChatMessageHistory / Postgres
# Rate limiting      In-memory counter      Redis INCR+EXPIRE or API Gateway
# LLM retries        asyncio.sleep backoff  Celery task queue with dead-letter
# Multi-file         asyncio.gather         Celery / Ray for true parallelism
# Auth               None                   JWT / API keys via middleware
# Observability      stdlib logging         OpenTelemetry + Datadog/Grafana
# Deployment         uvicorn single proc    gunicorn + uvicorn workers + k8s
# =============================================================================
